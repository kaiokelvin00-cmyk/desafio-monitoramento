#include <stdio.h>

#define TEMP_MIN -50.0
#define TEMP_MAX 100.0
#define CONSECUTIVAS_LIMITE 3

int main(void) {
    float limite;
    float temperatura;
    int consecutivas = 0;
    int primeira_leitura = 1;

    /*
     * O limite deve estar dentro da faixa definida para as leituras.
     * O do...while garante que o usuario informe um limite valido.
     */
    do {
        printf("Digite o limite de temperatura (%.0f a %.0f graus C): ", TEMP_MIN, TEMP_MAX);

        if (scanf("%f", &limite) != 1) {
            printf("Entrada invalida. Digite apenas um numero.\n");
            while (getchar() != '\n');
            limite = TEMP_MIN - 1;
        } else if (limite < TEMP_MIN || limite > TEMP_MAX) {
            printf("Limite invalido. Informe um valor entre %.0f e %.0f.\n", TEMP_MIN, TEMP_MAX);
        }
    } while (limite < TEMP_MIN || limite > TEMP_MAX);

    printf("\nMonitoramento iniciado.\n");
    printf("O programa encerra ao detectar %d temperaturas consecutivas acima do limite.\n\n",
           CONSECUTIVAS_LIMITE);

    /*
     * O while mantem o monitoramento enquanto as tres temperaturas
     * consecutivas acima do limite ainda nao foram atingidas.
     */
    while (consecutivas < CONSECUTIVAS_LIMITE) {
        printf("Digite a temperatura %s (%.0f a %.0f graus C): ",
               primeira_leitura ? "inicial" : "seguinte", TEMP_MIN, TEMP_MAX);

        if (scanf("%f", &temperatura) != 1) {
            printf("Entrada invalida. A leitura nao sera contabilizada.\n");
            while (getchar() != '\n');
            continue;
        }

        if (temperatura < TEMP_MIN || temperatura > TEMP_MAX) {
            printf("Temperatura invalida. Informe um valor entre %.0f e %.0f.\n\n",
                   TEMP_MIN, TEMP_MAX);
            continue;
        }

        if (temperatura > limite) {
            consecutivas++;
            printf("ALERTA: %.2f graus C esta acima do limite de %.2f graus C.\n",
                   temperatura, limite);
            printf("Temperaturas consecutivas acima do limite: %d/%d\n\n",
                   consecutivas, CONSECUTIVAS_LIMITE);
        } else {
            consecutivas = 0;
            printf("Temperatura normal: %.2f graus C.\n",
                   temperatura);
            printf("Contagem consecutiva reiniciada para 0.\n\n");
        }

        primeira_leitura = 0;
    }

    printf("MONITORAMENTO ENCERRADO!\n");
    printf("Foram detectadas %d temperaturas consecutivas acima do limite.\n", CONSECUTIVAS_LIMITE);

    return 0;
}
