# Desafio de Monitoramento de Temperatura

## 1. Identificação

- **Nome do aluno:** Kaio Kelvin de Souza Barros
- **Disciplina:** Ciências da Computação
- **Professora:** Profa. Karla Sartin
- **Título do projeto:** Estruturas de repetição

## 2. Objetivo

O programa simula um sistema simples de monitoramento de temperatura. O usuário informa um limite de temperatura e, em seguida, registra várias leituras. O sistema identifica quando uma temperatura está acima do limite e mantém uma contagem de ocorrências consecutivas. O monitoramento é encerrado automaticamente quando são registradas três temperaturas consecutivas acima do limite.

## 3. Funcionamento do programa

### Definição do limite

Primeiro, o usuário informa o limite de temperatura. Para manter a validação simples e consistente, o programa aceita limites entre **-50 °C e 100 °C**. Caso seja informado um valor fora dessa faixa ou um texto que não seja número, o programa solicita uma nova entrada.

### Leitura das temperaturas

Depois que o limite é definido, o programa solicita as temperaturas uma por uma. Cada leitura também deve estar entre **-50 °C e 100 °C**.

### Tratamento de valores inválidos

Entradas que não são números ou temperaturas fora da faixa permitida não são contabilizadas. O programa informa o erro e solicita uma nova leitura. Dessa forma, uma entrada inválida não interfere na contagem de temperaturas consecutivas.

### Identificação de temperaturas acima do limite

Quando uma leitura é maior que o limite informado pelo usuário, o programa apresenta uma mensagem de alerta e aumenta a contagem de temperaturas consecutivas acima do limite.

Uma temperatura **igual** ao limite não é considerada acima dele.

### Contagem de temperaturas consecutivas

A variável `consecutivas` guarda a quantidade de temperaturas acima do limite que ocorreram sem que uma temperatura normal interrompesse a sequência.

Se uma temperatura estiver no limite ou abaixo dele, a contagem é zerada. Assim, por exemplo, duas temperaturas acima do limite, seguidas de uma temperatura normal, não formam uma sequência de três.

### Condição de encerramento

O monitoramento termina quando a variável `consecutivas` chega a **3**. Nesse momento, o programa informa que foram detectadas três temperaturas consecutivas acima do limite e encerra a execução.

## 4. Estruturas de repetição utilizadas

O projeto utiliza **do...while** e **while**.

### do...while

O `do...while` é utilizado na definição do limite de temperatura. Essa estrutura foi escolhida porque o programa precisa solicitar o limite pelo menos uma vez antes de verificar se ele é válido. Caso o valor seja inválido, a entrada é repetida.

### while

O `while` é utilizado durante o monitoramento. A cada leitura válida, o programa verifica a condição de continuidade e repete o processo enquanto a contagem de temperaturas consecutivas acima do limite for menor que 3.

A combinação das duas estruturas deixa clara a diferença entre uma situação em que a execução precisa acontecer pelo menos uma vez (`do...while`) e uma situação em que a repetição depende da condição de continuidade (`while`).

## 5. Como executar

### Compilar

No terminal, dentro da pasta do projeto, execute:

```bash
gcc monitoramento.c -o monitoramento
```

### Executar no Windows

```bash
monitoramento.exe
```

### Executar no Linux/macOS

```bash
./monitoramento
```

## 6. Testes realizados

As evidências dos testes estão na pasta `evidencias/`.

### Teste 1 — Validação de entradas inválidas

Foram testadas entradas inválidas no limite e nas temperaturas. O programa rejeitou valores fora da faixa permitida e entradas que não eram números, solicitando uma nova informação sem contabilizar a entrada inválida.

**Evidência:** `evidencias/teste01.png`

### Teste 2 — Temperaturas acima do limite, porém não consecutivas

Foi utilizado o limite de **30 °C** e as temperaturas **35 °C, 28 °C, 36 °C, 29 °C e 34 °C**. As temperaturas acima do limite foram identificadas, mas as temperaturas abaixo do limite zeraram a contagem. Portanto, o programa não encerrou automaticamente.

**Evidência:** `evidencias/teste02.png`

### Teste 3 — Três temperaturas consecutivas acima do limite

Foi utilizado o limite de **30 °C** e as temperaturas **31 °C, 32 °C e 33 °C**. As três leituras ficaram acima do limite consecutivamente. Ao atingir 3/3, o programa encerrou automaticamente o monitoramento.

**Evidência:** `evidencias/teste03.png`

## 7. Estrutura do projeto

```text
desafio-monitoramento/
├── monitoramento.c
├── README.md
└── evidencias/
    ├── teste01.png
    ├── teste02.png
    └── teste03.png
```

## 8. Reflexão final

**Por que você escolheu while, do...while ou uma combinação das duas estruturas? Em qual parte do algoritmo a diferença entre testar a condição antes ou depois da execução foi importante para sua solução?**

Escolhi uma combinação de `do...while` e `while` porque cada estrutura atende melhor a uma parte do algoritmo. O `do...while` foi usado para solicitar o limite de temperatura, pois essa entrada precisa acontecer pelo menos uma vez antes de o programa verificar se o valor é válido. Já o `while` foi usado no monitoramento porque a repetição deve continuar somente enquanto ainda não houver três temperaturas consecutivas acima do limite. Dessa forma, a diferença entre testar a condição depois da primeira execução, no `do...while`, e testar a condição antes de cada nova repetição, no `while`, foi importante para controlar corretamente as duas etapas do programa.

## 9. Observação para a entrega

Antes de enviar o link no Blackboard, é importante publicar o projeto em um repositório público do GitHub e verificar o acesso em uma janela anônima do navegador. O repositório deve conter o código-fonte, o README e a pasta com as evidências dos testes.
